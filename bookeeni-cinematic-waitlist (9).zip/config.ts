// config.ts

// ACTION REQUIRED: Paste your deployed Google Apps Script Web App URL here.
// See the instructions provided to get this URL.
export const WEB_APP_URL = 'PASTE_YOUR_WEB_APP_URL_HERE';
