// analytics/collector.ts
import { v4 as uuidv4 } from 'uuid';

export interface VisitorData {
  visitorId: string;
  isReturning: boolean;
}

export interface UtmData {
  utm_source?: string | null;
  utm_medium?: string | null;
  utm_campaign?: string | null;
}

export interface DeviceData {
  device_type: string;
  browser_name: string;
  browser_version: string;
  os_name: string;
  os_version: string;
  screen_width: number;
  screen_height: number;
  language: string;
}

export const getVisitorData = (): VisitorData => {
  const STORAGE_KEY = 'bookeeni_visitor_id';
  let visitorId = localStorage.getItem(STORAGE_KEY);
  const isReturning = !!visitorId;

  if (!visitorId) {
    visitorId = uuidv4();
    localStorage.setItem(STORAGE_KEY, visitorId);
  }

  return { visitorId, isReturning };
};

export const getUtmData = (): UtmData => {
  const params = new URLSearchParams(window.location.search);
  return {
    utm_source: params.get('utm_source'),
    utm_medium: params.get('utm_medium'),
    utm_campaign: params.get('utm_campaign'),
  };
};

// A simple user-agent parser
const parseUserAgent = (ua: string) => {
    let browser_name = 'Unknown';
    let browser_version = 'Unknown';
    let os_name = 'Unknown';
    let os_version = 'Unknown';

    // Browser detection
    const chromeMatch = ua.match(/Chrome\/([\d.]+)/);
    const firefoxMatch = ua.match(/Firefox\/([\d.]+)/);
    const safariMatch = ua.match(/Version\/([\d.]+).*Safari/);
    const edgeMatch = ua.match(/Edg\/([\d.]+)/);

    if (edgeMatch) {
        browser_name = 'Edge';
        browser_version = edgeMatch[1];
    } else if (chromeMatch) {
        browser_name = 'Chrome';
        browser_version = chromeMatch[1];
    } else if (firefoxMatch) {
        browser_name = 'Firefox';
        browser_version = firefoxMatch[1];
    } else if (safariMatch) {
        browser_name = 'Safari';
        browser_version = safariMatch[1];
    }

    // OS detection
    if (/Windows NT ([\d.]+)/.test(ua)) {
        os_name = 'Windows';
        os_version = ua.match(/Windows NT ([\d.]+)/)![1];
    } else if (/Mac OS X ([\d_]+)/.test(ua)) {
        os_name = 'macOS';
        os_version = ua.match(/Mac OS X ([\d_]+)/)![1].replace(/_/g, '.');
    } else if (/Android ([\d.]+)/.test(ua)) {
        os_name = 'Android';
        os_version = ua.match(/Android ([\d.]+)/)![1];
    } else if (/iPhone OS ([\d_]+)/.test(ua)) {
        os_name = 'iOS';
        os_version = ua.match(/iPhone OS ([\d_]+)/)![1].replace(/_/g, '.');
    } else if (/Linux/.test(ua)) {
        os_name = 'Linux';
    }

    return { browser_name, browser_version, os_name, os_version };
};


export const getDeviceData = (): DeviceData => {
    const { browser_name, browser_version, os_name, os_version } = parseUserAgent(navigator.userAgent);
    
    return {
        device_type: 'ontouchstart' in window || navigator.maxTouchPoints > 0 ? 'mobile' : 'desktop',
        browser_name,
        browser_version,
        os_name,
        os_version,
        screen_width: window.screen.width,
        screen_height: window.screen.height,
        language: navigator.language,
    };
};
