// analytics/types.ts

export type AnalyticsEventType = 
  | 'session_start'
  | 'page_view'
  | 'click'
  | 'form_submission';

export interface AnalyticsEvent {
  event_type: AnalyticsEventType;
  event_details?: Record<string, any>;
}
