// analytics/AnalyticsProvider.tsx
import React, { createContext, useContext, useRef, useEffect, useCallback } from 'react';
import { supabase } from '../supabaseClient';
import { AnalyticsEvent, AnalyticsEventType } from './types';
import { getVisitorData, getUtmData, getDeviceData } from './collector';
import { v4 as uuidv4 } from 'uuid';

interface AnalyticsContextType {
  trackEvent: (eventType: AnalyticsEventType, details?: Record<string, any>) => void;
}

const AnalyticsContext = createContext<AnalyticsContextType | undefined>(undefined);

export const useAnalytics = () => {
  const context = useContext(AnalyticsContext);
  if (!context) {
    throw new Error('useAnalytics must be used within an AnalyticsProvider');
  }
  return context;
};

export const AnalyticsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const sessionDataRef = useRef<Record<string, any> | null>(null);
  const eventIndexRef = useRef(0);

  const initializeSession = useCallback(async () => {
    const sessionId = uuidv4();
    const { visitorId, isReturning } = getVisitorData();
    const utmData = getUtmData();
    const deviceData = getDeviceData();
    let geoData = {};

    try {
      const response = await fetch('https://ipapi.co/json/');
      if (response.ok) {
        geoData = await response.json();
      }
    } catch (error) {
      // Geo-location fetching is optional and can fail due to ad-blockers or network issues.
      // We'll proceed without it, and simply not log the warning to the console.
    }

    sessionDataRef.current = {
      session_id: sessionId,
      visitor_id: visitorId,
      is_returning: isReturning,
      landing_url: window.location.href,
      referrer: document.referrer,
      ...utmData,
      ...deviceData,
      geo_data: geoData,
    };

    trackEvent('session_start');
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    initializeSession();
  }, [initializeSession]);

  const sendToSupabase = useCallback(async (event: AnalyticsEvent) => {
    if (!sessionDataRef.current) return;

    eventIndexRef.current += 1;

    let is_converted = false;
    let conversion_type = null;

    if (event.event_type === 'form_submission') {
        is_converted = true;
        conversion_type = event.event_details?.form_id || 'unknown';
    }

    const payload = {
      ...sessionDataRef.current,
      event_type: event.event_type,
      event_details: event.event_details || {},
      page_url: window.location.href,
      duration_ms: event.event_details?.duration_ms || null,
      user_agent: navigator.userAgent,
      event_index: eventIndexRef.current,
      is_converted,
      conversion_type,
    };
    
    // Remove temporary detail from final payload
    if (payload.event_details.duration_ms) {
        delete payload.event_details.duration_ms;
    }

    const { error } = await supabase.from('visitor_analytics').insert([payload]);
    if (error) {
      console.error('Analytics submission error:', error);
    }
  }, []);

  const trackEvent = useCallback((eventType: AnalyticsEventType, details?: Record<string, any>) => {
    sendToSupabase({ event_type: eventType, event_details: details });
  }, [sendToSupabase]);

  return (
    <AnalyticsContext.Provider value={{ trackEvent }}>
      {children}
    </AnalyticsContext.Provider>
  );
};
