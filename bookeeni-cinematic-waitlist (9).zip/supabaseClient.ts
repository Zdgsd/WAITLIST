import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://qsahuopwwttratthqwbg.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFzYWh1b3B3d3R0cmF0dGhxd2JnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAxODg3NDgsImV4cCI6MjA3NTc2NDc0OH0.tOF5d6Ld-CIS_Vp4YmsP061bMF2gj22MIrvavmRnCw0';

if (!supabaseUrl || !supabaseKey) {
    throw new Error("Supabase URL and Key must be provided.");
}

export const supabase = createClient(supabaseUrl, supabaseKey);
